const chatHistory = document.getElementById('chatHistory');
const userInput = document.getElementById('userInput');
const sendBtn = document.getElementById('sendBtn');

let historyContext = []; // Stores context for the API

// Auto-resize textarea
userInput.addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = (this.scrollHeight) + 'px';
    if (this.value === '') this.style.height = 'auto';
});

function handleKeyPress(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
    }
}

function clearChat() {
    if(confirm('确定要清空对话记录吗？')) {
        historyContext = [];
        const bubbles = document.querySelectorAll('.message:not(:first-child)');
        bubbles.forEach(el => el.remove());
    }
}

function appendMessage(role, text) {
    const msgDiv = document.createElement('div');
    msgDiv.className = `message ${role}`;
    
    const icon = role === 'user' ? '<i class="fa-solid fa-user"></i>' : '<i class="fa-solid fa-robot"></i>';
    
    msgDiv.innerHTML = `
        <div class="avatar">${icon}</div>
        <div class="bubble">
            <div class="content"></div>
        </div>
    `;
    
    chatHistory.appendChild(msgDiv);
    
    // For assistant, we return the content div to facilitate streaming updates
    if (role === 'assistant') {
        chatHistory.scrollTop = chatHistory.scrollHeight;
        return msgDiv.querySelector('.content');
    } else {
        msgDiv.querySelector('.content').textContent = text;
        chatHistory.scrollTop = chatHistory.scrollHeight;
        return null;
    }
}

async function sendMessage() {
    const text = userInput.value.trim();
    if (!text) return;

    // UI Updates
    userInput.value = '';
    userInput.style.height = 'auto';
    sendBtn.disabled = true;
    
    appendMessage('user', text);

    // Create placeholder for assistant response
    const contentDiv = appendMessage('assistant', '');
    contentDiv.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> 思考中...';
    
    let fullResponse = "";

    try {
        const response = await fetch('/api/v1/chat/stream', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: text,
                history: historyContext,
                stream: true
            })
        });

        if (!response.ok) throw new Error('Network response was not ok');

        // Prepare for streaming
        contentDiv.innerHTML = ''; // Clear loading spinner
        const reader = response.body.getReader();
        const decoder = new TextDecoder();

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            
            const chunk = decoder.decode(value, { stream: true });
            fullResponse += chunk;
            
            // Real-time markdown parsing (simple version, full parsing at end is safer for incomplete tags)
            contentDiv.innerHTML = marked.parse(fullResponse);
            chatHistory.scrollTop = chatHistory.scrollHeight;
        }
        
        // Update history context
        historyContext.push({ role: "user", content: text });
        historyContext.push({ role: "assistant", content: fullResponse });

    } catch (error) {
        contentDiv.innerHTML = `<span style="color: #ef4444;"><i class="fa-solid fa-circle-exclamation"></i> 请求失败: ${error.message}</span>`;
    } finally {
        sendBtn.disabled = false;
        userInput.focus();
    }
}

function sendScenario(type) {
    let prompt = "";
    switch(type) {
        case '火灾':
            prompt = "站台发生火灾，我该怎么处理？";
            break;
        case '信号':
            prompt = "信号系统发生“红光带”故障，处置流程是什么？";
            break;
        case '客流':
            prompt = "发生严重拥挤踩踏风险时，值班站长的处置措施？";
            break;
    }
    userInput.value = prompt;
    sendMessage();
}

function loadScenario(type) {
    // Just for UI navigation effect
    document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
    event.currentTarget.classList.add('active');
}
